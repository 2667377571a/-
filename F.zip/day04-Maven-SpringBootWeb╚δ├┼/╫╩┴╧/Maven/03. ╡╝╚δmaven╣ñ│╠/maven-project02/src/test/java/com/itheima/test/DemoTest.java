package com.itheima.test;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DemoTest {
    private static Logger log = LoggerFactory.getLogger(DemoTest.class);

    @Test
    public void test1(){
        log.info("test1 ... running ...");
    }

}
