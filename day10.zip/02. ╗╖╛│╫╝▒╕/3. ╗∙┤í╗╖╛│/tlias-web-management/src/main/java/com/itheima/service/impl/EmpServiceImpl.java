package com.itheima.service.impl;

import com.itheima.service.EmpService;
import org.springframework.stereotype.Service;

@Service
public class EmpServiceImpl implements EmpService {
}
