package com.itheima.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * 部门管理Controller
 */
@RestController
public class DeptController {
}
