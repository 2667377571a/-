package com.itheima.mapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * 部门管理
 */
@Mapper
public interface DeptMapper {
}
