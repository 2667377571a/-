package com.itheima.service;

/**
 * 部门管理
 */
public interface DeptService {
}
