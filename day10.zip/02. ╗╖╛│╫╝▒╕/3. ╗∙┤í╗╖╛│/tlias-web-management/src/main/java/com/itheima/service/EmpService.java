package com.itheima.service;

/**
 * 员工管理
 */
public interface EmpService {
}
