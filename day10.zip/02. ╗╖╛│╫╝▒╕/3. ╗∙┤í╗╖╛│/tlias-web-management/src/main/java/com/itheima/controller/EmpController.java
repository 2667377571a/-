package com.itheima.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * 员工管理Controller
 */
@RestController
public class EmpController {
}
